package app.configs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;

@Configuration
public class ProfileConfig {

    @Autowired
    private static HashMap<String, String> profileMap;

    @Bean
    public static HashMap<String, String> getProfileMap() {
        profileMap = new HashMap<String, String>();
        profileMap.put("Super-Admin", "cnvbcnvb");
        profileMap.put("admin", "adminXY");
        profileMap.put("shourya", "1");
        profileMap.put("ajit", "ajit");
        profileMap.put("bhadri","bhadri");
        profileMap.put("ram","ram");
        profileMap.put("raju","raju");
        profileMap.put("dey","dey");
        profileMap.put("devang","devang");
        profileMap.put("sudharma", "sudharma");
        profileMap.put("shubham", "shubham");
        profileMap.put("kunal", "kunal");
        profileMap.put("shetty", "shetty");
        profileMap.put("hemanshu", "hemanshu");
        profileMap.put("anushka","anushka");
        profileMap.put("alvina","alvina");
        profileMap.put("nupoor","nupoor");
        profileMap.put("vivek","vivek");
        profileMap.put("anupama","anupama");
        profileMap.put("pravin","pravin");
        profileMap.put("tanya","tanya");
        profileMap.put("dj","dj");
        profileMap.put("ruchir","ruchir");
        return profileMap;
    }
}