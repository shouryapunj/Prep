package app.dto;

import java.util.Date;

public class ChatMessage {

    private String message;

    public ChatMessage() {

    }

    public ChatMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

}
